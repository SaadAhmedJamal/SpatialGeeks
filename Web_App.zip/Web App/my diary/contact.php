<?php require_once('Connections/dbconfig.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_Recordset1 = $_SESSION['MM_Username'];
}
mysql_select_db($database_dbconfig, $dbconfig);
$query_Recordset1 = sprintf("SELECT * FROM signup WHERE email = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $dbconfig) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

session_start();
if (!isset($_SESSION['MM_Username'])){
	
	header('login.php');
	} else {
		
		$l= "SELECT * FROM signup WHERE email = '{$_SESSION['MM_Username']}' ";
		$result= mysql_query($l);
		$user_ar= mysql_fetch_array($result);
		}
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Homepage</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
     
     
      
    </div>
  </div>
  <div id="main2">
 <body leftmargin="2" topmargin="2">
<form name="form" method="POST" action="<?php echo $editFormAction; ?>" onSubmit="return submitForm(this)">

  <table border="0" cellspacing="0"  width="677" id="AutoNumber1" height="377"  style="border-collapse: collapse" cellpadding="0">
   
   
    <tr > 
      <td height="19" colspan="3"> 
        <p align="left"> <font face="Verdana" style="font-size: 9pt"> <b><font color="#4A576B">&nbsp;Account 
          Information</font></b></font> 
      </td>
    </tr>
    <tr > 
      <td height="1" colspan="3">&nbsp; </td>
    </tr>
    <tr > 
      <td width="195" height="45"> 
        <p align="right"><font face="Verdana" style="font-size: 9pt" color="#003366"><b>Email:&nbsp;&nbsp; 
          </b></font> 
      </td>
      <td height="45" align="right" width="167"> 
        <p align="left"><font face="Verdana" style="font-size: 9pt" color="#000066"> 
          <input type="text" name="eMail" size="20" maxlength="50" onBlur="checkEmail(this)" style="border: 1px solid #B1C2D8">
          </font> 
      </td>
      <td width="315" height="45"><font class="s" style="font-size: 8pt" face="Verdana" color="#000066">Note:- 
        Email is your user name.</font></td>
    </tr>
    <tr > 
      <th width="195" height="9"> 
        <p align="right"> <font face="Verdana" style="font-size: 9pt" color="#003366">Password:&nbsp;&nbsp; 
          </font> 
      </th>
      <td height="30" align="right" width="167"> 
        <div align="left"><font face="Verdana" style="font-size: 9pt" color="#000066"> 
          <input type="password" name="password" size="20" maxLength="16" onBlur="checkPassword(this,6)" style="border:1px solid #B1C2D8; float: left">
          </font></div>
      </td>
      <td width="315" height="14"><font class="s" style="font-size: 8pt" face="Verdana" color="#000066"> 
        Note:- Password Must be at least six characters long.</font></td>
    </tr>
    </p>
    </td>
  <div id="main">
    <div class="leftmenu">
      <div class="nav">
        <ul>
         <li><a href="intro.php">Introduction</a></li>
          <li><a href="view.php">My Diary</a></li>
          <li><a href="contact.php">Contacts</a></li>
          <li><a href="video.php">Entertainment</a></li>
          <li><a href="lifeevent.php">Life Events</a></li>
          
          
        </ul>
      </div>
    </div>
  </div>
  <div id="prefooter"></div>
  <div id="footer">
   
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
