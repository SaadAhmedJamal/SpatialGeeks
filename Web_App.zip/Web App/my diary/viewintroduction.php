<?php require_once('Connections/dbconfig.php'); ?>

<?php
session_start();
if (!isset($_SESSION['MM_Username'])){
	
	header('login.php');
	} else {
		
		$l= "SELECT * FROM signup WHERE email = '{$_SESSION['MM_Username']}' ";
		$result= mysql_query($l);
		$user_ar= mysql_fetch_array($result);
		}
	
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$temp=$_SESSION['MM_Username'];
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_dbconfig, $dbconfig);
$query_Recordset1 = "SELECT * FROM introduction ";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $dbconfig) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;
 
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>View</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      <h2><?php echo $user_ar['firstname']; ?>'s diary</h2>
      
    </div>
    
  </div>
  <div id="main1">
    <table cellpadding="20" cellspacing="20">
      <tr>
        <td>First name</td>
        <td>last name</td>
        <td>Father name</td>
        <td>gender</td>
        <td>email</td>
        <td>cell no</td>
        <td>else</td>
        <td>degree</td>
      </tr>
      <?php do { ?>
        <tr>
          <td><?php echo $row_Recordset1['First name']; ?></td>
          <td><?php echo $row_Recordset1['last name']; ?></td>
          <td><?php echo $row_Recordset1['Father name']; ?></td>
          <td><?php echo $row_Recordset1['gender']; ?></td>
          <td><?php echo $row_Recordset1['email']; ?></td>
          <td><?php echo $row_Recordset1['cell no']; ?></td>
          <td><?php echo $row_Recordset1['else']; ?></td>
          <td><?php echo $row_Recordset1['degree']; ?></td>
        </tr>
        <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
    </table>
<div class="nav">
  
  
  
  
</div>
    
    

  </div>
  <div id="prefooter"></div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
