<?php require_once('Connections/dbconfig.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO ``life event`` (`event description`) VALUES (%s)",
                       GetSQLValueString($_POST['input'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Life event</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>


<body>

<param value="False" name="autoStart" />
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main">
    <div class="leftmenu">
      <div class="nav">
        <ul>
        
        
          <li><a href="photos.php">images</a></li>
          
            <li><a href="homepage.php">Home</a></li>
           
          
        </ul>
        <div style="
width: 585px;
height: 230px;
float: left;
background: scroll;
margin-right: 70px;
margin-top: px;
margin-bottom:400px;
margin-left: 160px; ">
  <marquee behavior="alternate" >
<img src=""  style="height:300px; width:250;" />
<img src=""  style="height:300px; width:250;" />
<img src=""  style="height:300px; width:250;" />

<br />
</marquee>
</div>
      </div>
    
    </div>
    <form id="form1" name="form1" method="post" action="">
      <label for="1">1</label>
    </form>
    
    
   
     <param value="True" name="Showcontrols" />
     <span class="nav">
    <div style="margin-left: 350px;
margin-top: 50px;"> <form method="POST" action="<?php echo $editFormAction; ?>" name="form" > <input name="input" type="text" style=" background-color:transparent" />
      <input type="hidden" name="MM_insert" value="form" />
    </form>
    </div>
   
    <div>
      <div id="main" style="width: 500px;
margin-left: 250px;" ></div>
</div>
    
  </div>
  
  
  
  <div id="prefooter">
  
    
  </div>
  
  
  
  <div id="footer">
    <div class="padding"> Copyright &copy; 2006 Your Site Name | Design: David Herreman </a> | Contact</a> | CSS</a> and XHTML</a> | </a> | >Login</a> </div>
  </div>
</div>

</body>
</html>