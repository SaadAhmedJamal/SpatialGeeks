<?php require_once('Connections/dbconfig.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO registration (`First Name`, `Last Name`, E-mail, Password, `Confirmation Password`) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['First name'], "text"),
                       GetSQLValueString($_POST['Last name'], "text"),
                       GetSQLValueString($_POST['mail'], "text"),
                       GetSQLValueString($_POST['pass'], "text"),
                       GetSQLValueString($_POST['Confirm'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO registration (`First Name`, `Last Name`, E-mail, Password, `Confirmation Password`) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['textfield'], "text"),
                       GetSQLValueString($_POST['textfield2'], "text"),
                       GetSQLValueString($_POST['textfield3'], "text"),
                       GetSQLValueString($_POST['textfield4'], "text"),
                       GetSQLValueString($_POST['textfield5'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form name="form" action="<?php echo $editFormAction; ?>" method="POST">
First Name<input name="First name" value="" type="text" /><br />
Last Name<input name="Last name" value="" type="text" /><br />
E-mail<input name="mail" value="" type="text" /> <br />
Password<input name="pass" type="text" value="" /><br />
Confirm Password<input name="Confirm" type="text" value="" /><br />
<input name="sub" type="button" value="Submit" />
<input type="hidden" name="MM_insert" value="form" />
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <p>
    <label for="textfield">first</label>
    <input type="text" name="textfield" id="textfield" />
  </p>
  <p>
    <label for="textfield2">last</label>
    <input type="text" name="textfield2" id="textfield2" />
  </p>
  <p>
    <label for="textfield3">mail</label>
    <input type="text" name="textfield3" id="textfield3" />
  </p>
  <p>
    <label for="textfield4">pass</label>
    <input type="text" name="textfield4" id="textfield4" />
  </p>
  <p>
    <label for="textfield5">comfirm</label>
    <input type="text" name="textfield5" id="textfield5" />
  </p>
  <p>
    <input type="submit" name="button" id="button" value="Submit" />
  </p>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>

</body>
</html>