<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>My Diary</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main">
  <div style="width:700px; height:250px;  background:scroll; margin-right:100px; margin-top:150px; margin-left:150px; margin-bottom: -230px; ">
<marquee behavior="alternate" >
<img src="sliderimage2.jpg" width="227"  style="height:300px; width:250;" />
<img src="sliderimage1.jpg" width="213"  style="height:300px; width:250;" />
<img src="imageslider8.jpg" width="213"  style="height:300px; width:250;" />

<br />
</marquee>
</div>
    <div class="leftmenu">
      <div class="nav">
        <ul>
         <li><a href="http://www.free-css.com/">Introduction</a></li>
          <li><a href="http://www.free-css.com/">My Diary</a></li>
          <li><a href="http://www.free-css.com/">Articles</a></li>
          <li><a href="entertainment.php">Entertainment</a></li>
          <li><a href="http://www.free-css.com/">Life Events</a></li>
          <li><a href="http://www.free-css.com/">Coming Events</a></li>
          <li><a href="http://www.free-css.com/">Goals</a></li>
          <li><a href="http://www.free-css.com/">Aims</a></li>
        </ul>
      </div>
      
    </div>
    
  </div>
  <div id="prefooter"></div>
  <div id="footer">
    <div class="padding"> Copyright &copy; 2006 Your Site Name | Design: <a href="http://www.free-css-templates.com">David Herreman </a> | <a href="http://www.free-css.com/">Contact</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> and <a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://www.solucija.com">Solucija.com</a> | <a href="http://www.free-css.com/">Login</a> </div>
  </div>
</div>
</body>
</html>
