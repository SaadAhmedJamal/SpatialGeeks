<?php

mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db("abc") or die(mysql_error());



if (isset($_REQUEST['upload']))
{
$name=$_FILES['uploadvideo']['name'];
 $type=$_FILES['uploadvideo']['type'];
$size=$_FILES['uploadvideo']['size'];
$cname=str_replace(" ","_",$name);
$tmp_name=$_FILES['uploadvideo']['tmp_name'];
$target_path="video";
$target_path=$target_path.basename($cname);

$by=$_POST['uploadedby'];
			$caption=$_POST['caption'];

if(move_uploaded_file($_FILES['uploadvideo']['tmp_name'],$target_path))
{
echo $sql="INSERT INTO video(term, location, uploadedby, caption) VALUE('".$cname."','".$target_path."','".$by."','".$caption."')"; 
if (!mysql_query($sql))
  {
  die('Error: ' . mysql_error());
  }
header("location: video.php");
exit();
$result=mysql_query($sql);
echo "Your video ".$cname." has been successfully uploaded";
}
}
			
	


?>