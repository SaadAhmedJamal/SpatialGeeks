-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2014 at 09:58 AM
-- Server version: 5.5.27-log
-- PHP Version: 5.4.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `abc`
--

-- --------------------------------------------------------

--
-- Table structure for table `imageupload`
--

CREATE TABLE IF NOT EXISTS `imageupload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `imageupload`
--

INSERT INTO `imageupload` (`id`, `title`, `image`) VALUES
(1, '', 'files/'),
(2, '', 'files/'),
(3, '', 'files/'),
(4, '', 'files/'),
(5, '', 'files/'),
(6, '', 'files/'),
(7, '', 'files/'),
(8, '', 'files/'),
(9, '', 'files/'),
(10, '', 'files/'),
(11, 'sdfsdfsdf', 'files/'),
(12, 'hehe', 'files/'),
(13, 'dfdsfsdf', 'files/'),
(14, '', 'files/'),
(15, 'xdvfx', 'files/');

-- --------------------------------------------------------

--
-- Table structure for table `introduction`
--

CREATE TABLE IF NOT EXISTS `introduction` (
  `First name` text NOT NULL,
  `last name` text NOT NULL,
  `Father name` text NOT NULL,
  `gender` text NOT NULL,
  `email` text NOT NULL,
  `cell no` text NOT NULL,
  `else` text NOT NULL,
  `degree` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `introduction`
--

INSERT INTO `introduction` (`First name`, `last name`, `Father name`, `gender`, `email`, `cell no`, `else`, `degree`) VALUES
('haseeb', 'ahmed', 'zahid', 'Male', 'haseebahmed121@gmail.com', '00332121', 'i want to finish this project...!!!', 'bs');

-- --------------------------------------------------------

--
-- Table structure for table `life event`
--

CREATE TABLE IF NOT EXISTS `life event` (
  `event description` text CHARACTER SET cp1250 NOT NULL,
  `date` text CHARACTER SET cp1250 NOT NULL,
  `location` text CHARACTER SET cp1250 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notepad`
--

CREATE TABLE IF NOT EXISTS `notepad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notepad` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `notepad`
--

INSERT INTO `notepad` (`id`, `notepad`) VALUES
(1, 'hello world\r\nIslamic University Islamabad\r\nPakistan'),
(4, 'my name is haseeb'),
(5, 'hi my name is haseeb and i am doing bsse');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `term` text NOT NULL,
  `location` text NOT NULL,
  `uploadedby` text NOT NULL,
  `caption` text NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`photo_id`, `term`, `location`, `uploadedby`, `caption`) VALUES
(3, 'Select Term', 'uploadedimage/imageslider4.jpg', '', ''),
(4, 'Select Term', 'uploadedimage/imageslider3.jpg', '', ''),
(5, 'Select Term', 'uploadedimage/musab 2.jpg', '', ''),
(6, 'Select Term', 'uploadedimage/14509_604343822938458_1648897451_a.jpg', '', ''),
(7, 'Select Term', 'uploadedimage/1146491_575434179185663_498977006_n.jpg', '', ''),
(8, 'Select Term', 'uploadedimage/1185559_533768873380047_386796662_n.jpg', '', ''),
(9, 'Select Term', 'uploadedimage/1151076_575835735812174_1457945974_n.jpg', '', ''),
(10, 'Select Term', 'uploadedimage/images.jpg', '', ''),
(11, 'Select Term', 'uploadedimage/1463670_692878207400709_2105779234_n.jpg', '', ''),
(12, 'Select Term', 'uploadedimage/imageslider4.jpg', '', ''),
(13, 'Select Term', 'uploadedimage/imageslider3.jpg', '', ''),
(14, 'Select Term', 'uploadedimage/995245_679164798808192_1370780861_n.png', '<br /><b>Notice</b>:  Undefined variable: _SESSION in <b>C:Program Files (x86)EasyPHP-12.1wwwmanuscriptupload.php</b> on line <b>61</b><br />', ''),
(15, 'Select Term', 'uploadedimage/1174980_10151700125949563_907476468_n.png', '<br /><b>Notice</b>:  Undefined variable: _SESSION in <b>C:Program Files (x86)EasyPHP-12.1wwwmanuscriptupload.php</b> on line <b>61</b><br />', '0');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `name` text CHARACTER SET armscii8 NOT NULL,
  `email` text CHARACTER SET armscii8 NOT NULL,
  `password` text CHARACTER SET armscii8 NOT NULL,
  `confirm_password` text CHARACTER SET armscii8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `email` text NOT NULL,
  `pass` text NOT NULL,
  `cpass` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `gender` text NOT NULL,
  `country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`email`, `pass`, `cpass`, `firstname`, `lastname`, `gender`, `country`) VALUES
('dadu@yahoo.com', '123456', '123456', 'lpc', 'lpc', 'Female', 'OM'),
('sdf@gdh.vbnb', '114477', '114477', 'fdgf', 'dfs', 'Male', 'PK'),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('usama@gmail.com', '123456', '123456', 'usama', 'ahmed', 'Male', 'PK'),
('choco@gmail.com', '123456', '123456', 'asdf', 'wqer', 'Male', 'PK');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `term` text NOT NULL,
  `location` text NOT NULL,
  `uploadedby` text NOT NULL,
  `caption` text NOT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`video_id`, `term`, `location`, `uploadedby`, `caption`) VALUES
(5, 'hhhhhhhhhh_480x360.mp4', 'videohhhhhhhhhh_480x360.mp4', 'bhut kala insan', 'black insan'),
(6, 'hhhhhhhhhh_480x360.mp4', 'videohhhhhhhhhh_480x360.mp4', 'newwww', 'newwwwwwwwwww');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
