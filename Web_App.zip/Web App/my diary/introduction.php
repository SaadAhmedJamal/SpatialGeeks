<?php require_once('Connections/dbconfig.php'); ?>
<?php
session_start();
if (!isset($_SESSION['MM_Username'])){
	
	header('login.php');
	} else {
		
		$l= "SELECT * FROM signup WHERE email = '{$_SESSION['MM_Username']}' ";
		$result= mysql_query($l);
		$user_ar= mysql_fetch_array($result);
		}
 ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO introduction (`First name`, `last name`, `Father name`, gender, email, `cell no`, `else`, degree) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['First_name'], "text"),
                       GetSQLValueString($_POST['last_name'], "text"),
                       GetSQLValueString($_POST['Father_name'], "text"),
                       GetSQLValueString($_POST['gender'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['cell_no'], "text"),
                       GetSQLValueString($_POST['else'], "text"),
                       GetSQLValueString($_POST['degree'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());

  $insertGoTo = "viewintroduction.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_username'])) {
  $colname_Recordset1 = $_SESSION['MM_username'];
}
mysql_select_db($database_dbconfig, $dbconfig);
$query_Recordset1 = sprintf("SELECT * FROM signup WHERE email = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $dbconfig) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Introduction</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
       <h2><?php echo $user_ar['firstname']; ?>'s diary</h2>
    </div>
  </div>
<div id="main1">
    <form action="<?php echo $editFormAction; ?>" method="POST" name="form1" id="form1">
      <table align="center">
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">First name:</td>
          <td><input type="text" name="First_name" value="" size="32"style="margin-bottom:10px;" /></td> <br />
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Last name:</td>
          <td><input type="text" name="last_name" value="" size="32" style="margin-bottom:10px;" /></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Father name:</td><br />
          <td><input type="text" name="Father_name" value="" size="32"style="margin-bottom:10px;" /></td><br />
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Gender:</td>
          <td> 
          <input name="gender" type="radio" value="Male" checked="checked" />
          Male 
          <input name="gender" type="radio" value="Female" />
          Female
         </td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Email:</td>
          <td><input type="text" name="email" value="" size="32" style="margin-bottom:10px;"/></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Cell no:</td>
          <td><input type="text" name="cell_no" value="" size="32" style="margin-bottom:10px;"  /></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Degree:</td>
          <td><input type="text" name="degree" value="" size="32" style="margin-bottom:10px;"/></td>
          </td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Else:</td>
          <td><input type="text" name="else" value="" size="70" style="margin-bottom:10px;"/>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">&nbsp;</td>
          
        </tr>
      </table>
      <a href="homepage.php">
      <input type="submit" value="Insert record" style=" size:500px;height: 30px;width: inherit;width: 100px;border: 2px solid #B1C2D8; background-color:transparent; border-color:#000; font-family:'Times New Roman', Times, serif " /></a>
      <input type="hidden" name="MM_insert" value="form1" />
    </form>
    
  </div>
  <div id="prefooter"></div>
</div>
</body>
</html>