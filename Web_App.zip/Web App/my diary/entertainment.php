<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<script type="text/javascript">
<!-->

var image1=new Image()
image1.src="sliderimage1.jpg"
var image2=new Image()
image2.src="sliderimage2.jpg"
var image3=new Image()
image3.src="imageslider3.jpg"
var image4=new Image()
image4.src="imageslider4.jpg"
var image5=new Image()
image5.src="imageslider5.jpg"
var image6=new Image()
image6.src="imageslider6.jpg"
var image7=new Image()
image7.src="imageslider7.jpg"
var image8=new Image()
image8.src="imageslider8.jpg"

//-->
</script>
<title>My Diary</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>

<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main">
    <div class="leftmenu">
      <div class="nav">
        <ul>
       <li><a href="entertainment.php">Entertainment</a></li>
          <li><a href="photos.php">images</a></li>
           <li><a href="video.php">videos</a></li>
            <li><a href="homepage.php">home</a></li>
        </ul>
      </div>
    </div>
    <div  style="margin-left: 280px; margin-right: 450px;
margin-bottom: -850px; margin-top: 150px;  " >  

<a  href="shop.html" style="border:groove;" >

<img src="sliderimage1.jpg" name="slide" width="400" height="250"  >

<script type="text/javascript" >
<!--
var step=1
function slideit(){
	document.images.slide.src=eval("image"+step+".src")
	if(step<8)
	step++
	else
	step=1
	setTimeout("slideit()",2500)
}
slideit()
//-->	
</script>
</a>
</div>
  </div>
  
  <div id="prefooter"></div>
  <div id="footer">
    <div class="padding"> Copyright &copy; 2006 Your Site Name | Design: <a href="http://www.free-css-templates.com">David Herreman </a> | <a href="http://www.free-css.com/">Contact</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> and <a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://www.solucija.com">Solucija.com</a> | <a href="http://www.free-css.com/">Login</a> </div>
  </div>
</div>
</body>
</html>
