<?php require_once('Connections/dbconfig.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// *** Redirect if username exists
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  $MM_dupKeyRedirect="registration.php";
  $loginUsername = $_POST['eMail'];
  $LoginRS__query = sprintf("SELECT email FROM signup WHERE email=%s", GetSQLValueString($loginUsername, "text"));
  mysql_select_db($database_dbconfig, $dbconfig);
  $LoginRS=mysql_query($LoginRS__query, $dbconfig) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $MM_qsChar = "?";
    //append the username to the redirect page
    if (substr_count($MM_dupKeyRedirect,"?") >=1) $MM_qsChar = "&";
    $MM_dupKeyRedirect = $MM_dupKeyRedirect . $MM_qsChar ."requsername=".$loginUsername;
    header ("Location: $MM_dupKeyRedirect");
    exit;
  }
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO signup (email, pass, cpass, firstname, lastname, gender, country) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['eMail'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['confirmPassword'], "text"),
                       GetSQLValueString($_POST['firstName'], "text"),
                       GetSQLValueString($_POST['lastName'], "text"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['country'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());

  $insertGoTo = "login.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<script language="javascript">

	function checkNum(e)
	{		
		if(isNaN(e.value))
		{
			alert("Please! Enter only numeric value");
			e.select();				
			e.focus();
		}
	}
	
	function checkChar(e)
	{
		for(i=0; i<e.value.length; i++)
		{
			if(e.value.charAt(i) != ' ' )
			if(!isNaN(e.value.charAt(i)))
			{
				alert("Please Enter only character value.");
				e.select();
				e.focus();
				break;
			}
		}
	}
	
	function checkPassword(e, length)
	{
		if(e.value.length==0)
			return;
		if(e.value.length < length)
		{
			alert("Please! Enter minimum "+length+" password length field." );
			e.select();
			e.focus();		
		}		
	}

	function checkConfirmPassword(e, length)
	{
		if(e.value.length==0)
			return;
		if(e.value.length < length)
		{
			alert("Please! Enter correct format of ID field.");
			e.select();
			e.focus();		
		}		
	}
	
		 
	
	 
	function submitForm(f)
	{	
		var userpass = f.password.value;
		var confirmPass = f.confirmPassword.value;
			

		var showError ="";

		if( f.password.value =="" )
			showError +="- User Password Name field is required.\n";	
		if( f.confirmPassword.value =="" )
			showError +="- Confirm Password Name field is required.\n";	
		if ( userpass != confirmPass )
			showError +="- Confirm Password is incorrect.\n";
		if( f.firstName.value =="" )
			showError +="- First Name field is required.\n";	
		if( f.lastName.value =="" )
			showError +="- Last Name field is required.\n";	
		if( f.eMail.value =="" )
			showError +="- Email field is required.\n";	
		if( f.country.value =="" )
			showError +="- Country field is required.\n"; 
		if( f.answer.value =="" )
			showError +="- Your  Secrit Answer Require.\n";	
		if ( showError != "" ){
			alert("The following Error(s) occurred \n\n"+showError);
			return false;
		}
		else  
					return true;
		
	}

	
	function checkEmail(e)
	{
		email = e.value;		
		if(email=="")
		   return;
		
		count=0;
		for(i=0; i<email.length; i++)
		{
 			if(email.charAt(i)=='@')
			{
				count++;
				atPos=i;
			}
			if(email.charAt(i)=='@' && i==0)
			{
				wrongEmail(e);			
				return;
			}

		}

		if(count!=1)
		{
			wrongEmail(e);
			return;
		}

		right=0;
		for(j=0; j<atPos; j++)
		{
			if(email.charAt(j)!=' ')
			{
				right=1;
			}
		}

		
		if(right==0)
		{
			wrongEmail(e);
			return;
		}
		right2=0;		
		for(i=atPos+1; i<email.length; i++)
		{
			if(email.charAt(i)=='.')
				right2=1;			
		}

		
		if(right2==0)
		{
			wrongEmail(e);
			return;			
		}

		
		for(i=atPos+1; i<email.length; i++)
		{
			c = email.charAt(i);
			c_ascii = c.charCodeAt(0);

			if(c=='.' || (c_ascii>=48 && c_ascii<=57) ||
			 (c_ascii>=65 && c_ascii<=90) || (c_ascii>=97 && c_ascii<=122) )
			{
				
			}
			
			else
			{		
			wrongEmail(e);
			return;
			}
		}

		for(firstDot=atPos+1; firstDot<email.length; firstDot++)
		{
			if(email.charAt(firstDot)=='.')
			  break;
		}
		if(firstDot==((email.length)-1))
		{	
			wrongEmail(e);
			return;
		}		

		getDot = 1;
		for(i=atPos+1; i<email.length; i++)
		{
			if(email.charAt(i)=='.')
			{
				if(getDot==1)
				{
					wrongEmail(e);
					return;	
				}
				else
				   getDot=1;
			}
			else
			    getDot = 0;
		}	
		
		
	}

	function wrongEmail(e)
	{
		alert("Please! enter valid Email address.");
		e.select();				
		e.focus();
	}
	
	function checkNames(e)
	{
		if(e.value.length==0)
		  return;
		  validname=1;
		for(i=0; i<e.value.length; i++)
		{
			if(e.value.charAt(i)!=' ')
			if(!isNaN(e.value.charAt(i)))
			{
				alert("Please! enter only character value.");
				e.select();
				e.focus();
				validname=0;
				break;	
			}
		}

		if(validname==1)
		{
		   	nam = e.value;
		   	for(j=0; j<nam.length; j++)
		   {	
				charE = nam.charAt(j);
				ascii = charE.charCodeAt(0);

      		     if(charE=='-' || charE==' ' || (ascii>=65 && ascii<=90) || (ascii>=97 && ascii<=122))
		     	{
		     	}
		      else
					{
						alert("Please! enter valid name.");
						e.select();
						e.focus();
						break;
			 		}
		  	 }
	        }   
	}
</script> 


<title>Register</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main2">
 <body leftmargin="2" topmargin="2">
<form name="form" method="POST" action="<?php echo $editFormAction; ?>" onSubmit="return submitForm(this)">

  <table border="0" cellspacing="0"  width="677" id="AutoNumber1" height="377"  style="border-collapse: collapse" cellpadding="0">
   
   
    <tr > 
      <td height="19" colspan="3"> 
        <p align="left"> <font face="Verdana" style="font-size: 9pt"> <b><font color="#4A576B">&nbsp;Account 
          Information</font></b></font> 
      </td>
    </tr>
    <tr > 
      <td height="1" colspan="3">&nbsp; </td>
    </tr>
    <tr > 
      <td width="195" height="45"> 
        <p align="right"><font face="Verdana" style="font-size: 9pt" color="#003366"><b>Email:&nbsp;&nbsp; 
          </b></font> 
      </td>
      <td height="45" align="right" width="167"> 
        <p align="left"><font face="Verdana" style="font-size: 9pt" color="#000066"> 
          <input type="text" name="eMail" size="20" maxlength="50" onBlur="checkEmail(this)" style="border: 1px solid #B1C2D8">
          </font> 
      </td>
      <td width="315" height="45"><font class="s" style="font-size: 8pt" face="Verdana" color="#000066">Note:- 
        Email is your user name.</font></td>
    </tr>
    <tr > 
      <th width="195" height="9"> 
        <p align="right"> <font face="Verdana" style="font-size: 9pt" color="#003366">Password:&nbsp;&nbsp; 
          </font> 
      </th>
      <td height="30" align="right" width="167"> 
        <div align="left"><font face="Verdana" style="font-size: 9pt" color="#000066"> 
          <input type="password" name="password" size="20" maxLength="16" onBlur="checkPassword(this,6)" style="border:1px solid #B1C2D8; float: left">
          </font></div>
      </td>
      <td width="315" height="14"><font class="s" style="font-size: 8pt" face="Verdana" color="#000066"> 
        Note:- Password Must be at least six characters long.</font></td>
    </tr>
    <tr > 
      <th width="195" height="45"> 
        <p align="right"> <font face="Verdana" style="font-size: 9pt" color="#003366">Confirm&nbsp;&nbsp; 
          Password:&nbsp;&nbsp; </font> 
      </th>
      <td height="30" align="right" width="167"> 
        <div align="left"><font face="Verdana" style="font-size: 9pt" color="#000066"> 
          <input type="password" name="confirmPassword" size="20" maxLength="16" onBlur="checkConfirmPassword(this,6)" style="border:1px solid #B1C2D8; float: left">
          </font></div>
      </td>
      <td width="315" height="14">&nbsp;</td>
    </tr>
    <tr > 
      <td height="19" colspan="3">&nbsp; </td>
    </tr>
    <tr> 
      <td height="19" colspan="3"> <font face="Verdana" style="font-size: 9pt"> 
        <b> <font color="#4A576B">&nbsp;Profile Information</font></b></font></td>
    </tr>
    <tr> 
      <td width="195" height="1" valign="middle" align="right" >&nbsp; 
      </td>
      <td height="1" colspan="2" align="left">&nbsp; </td>
    </tr>
    <tr> 
      <td width="195" height="36" valign="middle" align="right" > 
        <p class="s11px"> <font face="Verdana" style="font-size: 9pt" color="#003366"><b>First 
          Name:&nbsp;&nbsp; </b></font></p>
      </td>
      <td height="36" colspan="2" align="left" > <font face="Verdana" style="font-size: 9pt" color="#003366"> 
        <input type="text" name="firstName" size="20" maxLength="15" onBlur="checkNames(this)" style="border: 1px solid #B1C2D8">
        </font></td>
    </tr>
    <tr> 
      <td width="195" height="27" valign="middle" align="right" > 
        <p class="s11px"> <font face="Verdana" style="font-size: 9pt" color="#003366"><b>Last 
          Name:&nbsp;&nbsp; </b></font> 
      </td>
      <td height="27" colspan="2" align="left" > <font face="Verdana" style="font-size: 9pt" color="#003366"> 
        <input type="text" name="lastName" size="20" maxLength="15" onBlur="checkNames(this)" style="border: 1px solid #B1C2D8">
        </font></td>
    </tr>
    <tr> 
      <td width="195" height="27" valign="middle" > 
        <p align="right"> <font face="Verdana" style="font-size: 9pt" color="#003366"><b>Gender:&nbsp;&nbsp; 
          </b></font> 
      </td>
      <td height="27" colspan="2" align="left"> <font face="Verdana" color="#003366"><span style="font-size: 9pt"> 
        <select name="sex" style="border: 1px solid #B1C2D8; ">
          <option><font color="#003366">Male </font></option>
          <option><font color="#003366">Female </font></option>
        </select>
        </span></font></td>
    </tr>
    <tr> 
      <td width="195" height="29" align="right" valign="middle" > 
        <p> <font face="Verdana" style="font-size: 9pt" color="#003366"><b>Country:&nbsp;&nbsp; 
          </b></font> 
      </td>
      <td height="29" colspan="2" align="left" > <font color="#003366"> 
        <SELECT name=country style="border: 1px solid #B1C2D8;" >
          <OPTION value=AF>Afghanistan 
          <OPTION value=AL>Albania 
          <OPTION 
        value=DZ>Algeria 
          <OPTION value=AS>American Samoa 
          <OPTION 
        value=AD>Andorra 
          <OPTION value=AO>Angola 
          <OPTION value=AI>Anguilla 
          <OPTION 
        value=AQ>Antarctica 
          <OPTION value=AG>Antigua And Barbuda 
          <OPTION 
        value=AR>Argentina 
          <OPTION value=AM>Armenia 
          <OPTION value=AW>Aruba 
          <OPTION 
        value=AU>Australia 
          <OPTION value=AT>Austria 
          <OPTION 
        value=AZ>Azerbaijan 
          <OPTION value=BS>Bahamas, The 
          <OPTION 
        value=BH>Bahrain 
          <OPTION value=BD>Bangladesh 
          <OPTION 
        value=BB>Barbados 
          <OPTION value=BY>Belarus 
          <OPTION value=BE>Belgium 
          <OPTION 
        value=BZ>Belize 
          <OPTION value=BJ>Benin 
          <OPTION value=BM>Bermuda 
          <OPTION 
        value=BT>Bhutan 
          <OPTION value=BO>Bolivia 
          <OPTION value=BW>Botswana 
          <OPTION value=BR>Brazil 
          <OPTION value=BN>Brunei 
          <OPTION value=BG>Bulgaria 
          <OPTION value=BI>Burundi 
          <OPTION 
        value=KH>Cambodia 
          <OPTION value=CM>Cameroon 
          <OPTION value=CA>Canada 
          <OPTION 
        value=CV>Cape Verde 
          <OPTION value=TD>Chad 
          <OPTION 
        value=CL>Chile 
          <OPTION value=CN>China 
          <OPTION value=CX>Christmas Island 
          <OPTION 
        value=CO>Colombia 
          <OPTION value=KM>Comoros 
          <OPTION value=CG>Congo 
          <OPTION value=CK>Cook Islands 
          <OPTION value=CR>Costa Rica 
          <OPTION value=CU>Cuba 
          <OPTION 
        value=CY>Cyprus 
          <OPTION value=CZ>Czech Republic 
          <OPTION 
        value=DK>Denmark 
          <OPTION value=DJ>Djibouti 
          <OPTION 
        value=DM>Dominica 
          <OPTION value=DO>Dominican Republic 
          <OPTION 
        value=TP>East Timor 
          <OPTION value=EC>Ecuador 
          <OPTION value=EG>Egypt 
          <OPTION 
        value=SV>El Salvador 
          <OPTION value=GQ>Equatorial Guinea 
          <OPTION 
        value=ER>Eritrea 
          <OPTION value=EE>Estonia 
          <OPTION value=ET>Ethiopia 
          <OPTION value=FO>Faroe Islands 
          <OPTION value=FJ>Fiji Islands 
          <OPTION value=FI>Finland 
          <OPTION 
        value=FR>France 
          <OPTION 
        value=GA>Gabon 
          <OPTION 
        value=GE>Georgia 
          <OPTION value=DE>Germany 
          <OPTION value=GH>Ghana 
          <OPTION 
        value=GI>Gibraltar 
          <OPTION value=GR>Greece 
          <OPTION 
        value=GL>Greenland 
          <OPTION value=GD>Grenada 
          <OPTION 
        value=GP>Guadeloupe 
          <OPTION value=GU>Guam 
          <OPTION 
        value=GT>Guatemala 
          <OPTION value=GN>Guinea 
          <OPTION 
        value=GW>Guinea-Bissau 
          <OPTION value=GY>Guyana 
          <OPTION 
        value=HT>Haiti 
          <OPTION 
        value=HN>Honduras 
          <OPTION value=HK>Hong Kong S.A.R. 
          <OPTION 
        value=HU>Hungary 
          <OPTION value=IS>Iceland 
          <OPTION value=IN>India 
          <OPTION 
        value=ID>Indonesia 
          <OPTION value=IR>Iran 
          <OPTION value=IQ>Iraq 
          <OPTION 
        value=IE>Ireland 
          <OPTION value=IL>Israel 
          <OPTION value=IT>Italy 
          <OPTION 
        value=JM>Jamaica 
          <OPTION value=JP>Japan 
          <OPTION value=JO>Jordan 
          <OPTION 
        value=KZ>Kazakhstan 
          <OPTION value=KE>Kenya 
          <OPTION 
        value=KI>Kiribati 
          <OPTION value=KR>Korea 
          <OPTION value=KP>Korea, North 
          <OPTION value=KW>Kuwait 
          <OPTION value=KG>Kyrgyzstan 
          <OPTION 
        value=LA>Laos 
          <OPTION value=LV>Latvia 
          <OPTION value=LB>Lebanon 
          <OPTION 
        value=LS>Lesotho 
          <OPTION value=LR>Liberia 
          <OPTION value=LY>Libya 
          <OPTION 
        value=LI>Liechtenstein 
          <OPTION 
        value=LU>Luxembourg 
          <OPTION 
        value=MG>Madagascar 
          <OPTION value=MW>Malawi 
          <OPTION 
        value=MY>Malaysia 
          <OPTION value=MV>Maldives 
          <OPTION value=ML>Mali 
          <OPTION 
        value=MT>Malta 
          <OPTION value=MH>Marshall Islands 
          <OPTION 
        value=MQ>Martinique 
          <OPTION value=MR>Mauritania 
          <OPTION 
        value=MU>Mauritius 
          <OPTION value=YT>Mayotte 
          <OPTION value=MX>Mexico 
          <OPTION 
        value=FM>Micronesia 
          <OPTION value=MD>Moldova 
          <OPTION 
        value=MC>Monaco 
          <OPTION value=MN>Mongolia 
          <OPTION 
        value=MS>Montserrat 
          <OPTION value=MA>Morocco 
          <OPTION 
        value=MZ>Mozambique 
          <OPTION value=MM>Myanmar 
          <OPTION 
        value=NA>Namibia 
          <OPTION value=NR>Nauru 
          <OPTION value=NP>Nepal 
          <OPTION value=NZ>New Zealand 
          <OPTION value=NE>Niger 
          <OPTION value=NG>Nigeria 
          <OPTION value=NO>Norway 
          <OPTION value=OM>Oman 
          <OPTION 
        value=PK selected>Pakistan 
          <OPTION value=PA>Panama 
          <OPTION value=PY>Paraguay 
          <OPTION 
        value=PE>Peru 
          <OPTION value=PH>Philippines 
          <OPTION value=PL>Poland 
          <OPTION value=PT>Portugal 
          <OPTION 
        value=PR>Puerto Rico 
          <OPTION value=QA>Qatar 
          <OPTION 
        value=RE>Reunion 
          <OPTION value=RO>Romania 
          <OPTION value=RU>Russia 
          <OPTION 
        value=RW>Rwanda 
          <OPTION 
        value=WS>Samoa 
          <OPTION value=SM>San Marino 
          <OPTION value=SA>Saudi Arabia 
          <OPTION value=SN>Senegal 
          <OPTION 
        value=SC>Seychelles 
          <OPTION 
        value=SG>Singapore 
          <OPTION value=SK>Slovakia 
          <OPTION 
        value=SI>Slovenia 
          <OPTION 
        value=SO>Somalia 
          <OPTION value=ZA>South Africa 
          <OPTION value=ES>Spain 
          <OPTION 
        value=LK>Sri Lanka 
          <OPTION value=SD>Sudan 
          <OPTION value=SR>Suriname 
          <OPTION value=SZ>Swaziland 
          <OPTION 
        value=SE>Sweden 
          <OPTION value=CH>Switzerland 
          <OPTION value=SY>Syria 
          <OPTION 
        value=TW>Taiwan 
          <OPTION value=TJ>Tajikistan 
          <OPTION 
        value=TZ>Tanzania 
          <OPTION value=TH>Thailand 
          <OPTION value=TG>Togo 
          <OPTION 
        value=TK>Tokelau 
          <OPTION value=TO>Tonga 
          <OPTION value=TN>Tunisia 
          <OPTION value=TR>Turkey 
          <OPTION 
        value=TM>Turkmenistan 
          <OPTION 
        value=TV>Tuvalu 
          <OPTION value=UG>Uganda 
          <OPTION value=UA>Ukraine 
          <OPTION 
        value=AE>United Arab Emirates 
          <OPTION value=UK>United Kingdom 
          <OPTION value=US>United States 
          <OPTION value=UY>Uruguay 
          <OPTION 
        value=UZ>Uzbekistan 
          <OPTION value=VU>Vanuatu 
          <OPTION value=VE>Venezuela 
          <OPTION 
        value=VN>Vietnam 
          <OPTION value=YE>Yemen 
          <OPTION value=YU>Yugoslavia 
          <OPTION 
        value=ZM>Zambia 
          <OPTION value=ZW>Zimbabwe</OPTION>
        </SELECT>
        </font></td>
    </tr>
    
    
   
    <tr> 
      <td height="21" valign="middle" colspan="3" >&nbsp;</td>
    </tr>
    <tr> 
      <td width="195" height="24" >&nbsp;</td>
      <td height="24" colspan="2" > 
        <input type="submit" value="Submit" name="Submit" style="border: 2px solid #B1C2D8; background-color: #F6F9FF" >
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <input type="reset" value="Reset" name="reset" style="border: 2px solid #B1C2D8; background-color: #F6F9FF">
      </td>
    </tr>
    <tr> 
      <td height="29" colspan="3" >&nbsp;</td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form" />
  <input type="hidden" name="MM_insert" value="form" />
</form>

<table width="778" border="0" height="19">
  <tr>
    <td height="19" >
      
    </td>
  </tr>
</table>

 
  </div>
 
</div>

</div>
<div id="prefooter" style="margin-left:265px">
    
</div>
</body>
</html>

