<div id="bottom-sidebar">

        <div class="wrapper">

            <div class="row">

                <div class="col-md-4 col-sm-4 col-xs-4 wow fadeInUp" data-wow-duration="0.2s" data-wow-delay="0.2s">

                    <div class="widget kopa-contact-widget">
                        <h3 class="widget-title">Contact-info</h3>
                        <address>
                            <p>Seham Street Pirwadahi Mor Rawalpindi</p>
                            <p><i class="fa fa-map-marker"></i><span class="media-body">DesignPalce <br>
                            <i>&nbsp;&nbsp;</i><i>&nbsp;&nbsp;</i><i>&nbsp;&nbsp;</i><i>&nbsp;&nbsp;</i><i>&nbsp;&nbsp;</i>West Babra Bazar Raja Bazar</span></p>
                            <p><i class="fa fa-phone"></i>0313 5133121</p>
                             <p><i class="fa fa-phone"></i>0334 5294743</p>
                            <p><i class="fa fa-envelope-o"></i><a href="mailto:info@designpalace.com">info@designpalace.com</a></p>
                        </address>
                    </div>
                    <!-- widget -->

                </div>
                <!-- col-md-4 -->

                <div class="col-md-2 col-sm-2 col-xs-2 wow fadeInUp" data-wow-duration="0.2s" data-wow-delay="0.2s">

                    <div class="widget widget_text">
                        <h3 class="widget-title">Important Links</h3>
                        <div class="textwidget">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="logo.php">Logo Design</a></li>
                                <li><a href="businesscard.php">Business Card Design</a></li>
                                <li><a href="wedding_card.php">Wedding Card Design</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- widget -->

                </div>
                <!-- col-md-2 -->

                <div class="col-md-2 col-sm-2 col-xs-2 wow fadeInUp" data-wow-duration="0.2s" data-wow-delay="0.2s">

                    <div class="widget widget_text">
                        <h3 class="widget-title">Quick links</h3>
                        <div class="textwidget">
                            <ul>
                                <li><a href="faqs.php">FAQs</a></li>
                                <li><a href="term.php">Terms and Conditions</a></li>
                                <li><a href="privacy.php">Privacy Policy</a></li>
                              
                            </ul>
                        </div>
                    </div>
                    <!-- widget -->

                </div>
                <!-- col-md-2 -->
<div class="col-md-2 col-sm-2 col-xs-2 wow fadeInUp" data-wow-duration="0.2s" data-wow-delay="0.2s">

                    <div class="widget widget_text">
                        <h3 class="widget-title">Location</h3>
                        <div class="textwidget">
                            
                        </div>
                    </div>
                    <!-- widget -->

                </div>
                
                <!-- col-md-2 -->

                
                <!-- col-md-2 -->

            </div>
            <!-- row -->

        </div>
        <!-- wrapper -->

    </div>
<footer id="kopa-page-footer">
        <div class="wrapper clearfix">
            <p id="copyright" class="pull-left">&copy; 2014 All rights reserved.  Theme by <a href="www.wlssoft.com">WlsSoft</a></p>

            <nav id="footer-nav" class="pull-right">
                <ul id="footer-menu" class="clearfix">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="faqs.php">FAQ</a></li>
                    <li><a href="term.php">Terms and Conditions</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            <!-- footer-nav -->
        </div>
        <!-- wrapper -->

        <p id="back-top">
            <a href="#top"></a>
        </p>
    </footer>