<?php require_once('Connections/dbconfig.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_dbconfig, $dbconfig);
$query_Recordset1 = "SELECT * FROM photos";
$Recordset1 = mysql_query($query_Recordset1, $dbconfig) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>admin panel</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>
<!-- Header -->
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
			<h1><a href="index members.php">Admin Panel</a></h1>
			<div id="top-navigation">
				Welcome <a href="index members.php"><strong>Administrator</strong></a>
				<span>|</span>
				<a href="#">Help</a>
				<span>|</span>
				<a href="#">Profile Settings</a>
				<span>|</span>
				<a href="#">Log out</a>
			</div>
		</div>
		<!-- End Logo + Top Nav -->
		
		<!-- Main Nav -->
		<div id="navigation">
			<ul>
		        <li><a href="index members.php" class="active"><span>Members</span></a></li>
			    <li><a href="index note pad.php"><span>Note pad</span></a></li>
			    <li><a href="index videos.php"><span>Video Gallery</span></a></li>
			    <li><a href="index photos.php"><span>Photo Gallery</span></a></li>
			    <li><a href="index intro.php"><span>Member Intro</span></a></li>
			    
			</ul>
		</div>
		<!-- End Main Nav -->
	</div>
</div>
<!-- End Header -->

<!-- Container -->
<div id="container">
	<div class="shell">
		
		<!-- Small Nav -->
		<div class="small-nav">
			<a href="#">Dashboard</a>
			<span>&gt;</span>
			Current Articles
		</div>
		<!-- End Small Nav -->
		
		<!-- Message OK --><!-- End Message OK -->		
		
		<!-- Message Error -->
		<p>
		  <!-- End Message Error -->
	  </p>
	  <table border="3" cellpadding="4" cellspacing="4">
          <tr>
            <td>photo_id</td>
            <td>term</td>
            <td>location</td>
            <td>uploadedby</td>
            <td>caption</td>
        </tr>
          <?php do { ?>
            <tr>
              <td><?php echo $row_Recordset1['photo_id']; ?></td>
              <td><?php echo $row_Recordset1['term']; ?></td>
              <td><?php echo $row_Recordset1['location']; ?></td>
              <td><?php echo $row_Recordset1['uploadedby']; ?></td>
              <td><?php echo $row_Recordset1['caption']; ?></td>
             <td> <a href="index photos delete.php?photo_id=<?php echo $row_Recordset1['photo_id']; ?>"> delete </a></td>
            </tr>
            <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
      </table>
<p><br />
		  <!-- Main -->
	  </p>
		<div id="main">
		  <div class="cl">&nbsp;		  </div>
			
			<!-- Content --><!-- End Content -->
			
			<!-- Sidebar -->
			<div id="sidebar">
				
				<!-- Box --><!-- End Box -->
		  </div>
			<!-- End Sidebar -->
			
			<div class="cl">&nbsp;</div>			
	  </div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->

<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left">&copy; 2013 - Usama</span>
		<span class="right">
			Design by <a href="index members.php" target="_blank" title="Online Diary">Usama & Haseeb</a>
		</span>
	</div>
</div>
<!-- End Footer -->
	
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
