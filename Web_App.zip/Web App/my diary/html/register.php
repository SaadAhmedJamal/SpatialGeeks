<?php require_once('Connections/dbconfig.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO introduction (`First name`, email, `cell no`) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['password'], "text"));

  mysql_select_db($database_dbconfig, $dbconfig);
  $Result1 = mysql_query($insertSQL, $dbconfig) or die(mysql_error());
}
?>
<?php require_once("Connections/dbconfig.php");

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("designpalace", $con);

if(isset($_POST['submit']))
{
	
	$name = $_POST['name'];
	$password = $_POST['password'];
	$visitor_email = $_POST['email'];
	
	///------------Do Validations-------------
	
	$qry = "SELECT * FROM register WHERE email='$visitor_email' ";
		$result = mysql_query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
			echo '<script type="text/javascript">
			alert("Email is already in use");
			</script>';
							}	
							else
							{
		$qry = "INSERT INTO register(username, email, password) VALUES('$name','$visitor_email','$password')";
	$result = @mysql_query($qry);
	if($result)
	{
		echo '<script type="text/javascript">
			alert("Thanks for registration");
			</script>';

	}
							}
		}
	}

 ?>
<!DOCTYPE html>
<html lang="en">
    

<head>
        <meta charset="utf-8">
        <title>DesignPalace - Register</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="stylesheet" href="css/bootstrap.css" media="all" />
        <link rel="stylesheet" href="css/font-awesome.css" media="all" />
        <link rel="stylesheet" href="css/superfish.css" media="all" />
        <link rel="stylesheet" href="css/owl.carousel.css" media="all" />
        <link rel="stylesheet" href="css/owl.theme.css" media="all" />
        <link rel="stylesheet" href="css/jquery.navgoco.css"/>
        <link rel="stylesheet" href="css/colorbox.css" media="all" />
        <link rel="stylesheet" href="style.css">

        <script src="js/modernizr.custom.js"></script>


        <!--[if lt IE 9]>
            <link rel="stylesheet" href="css/ie.css" type="text/css" media="all" />
        <![endif]-->

        <!--[if IE 9]>
            <link rel="stylesheet" href="css/ie9.css" type="text/css" media="all" />
        <![endif]-->

        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="img/favicon.html">
        <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

    </head>
    
<body class="kopa-about-page">

    <?php include('header.php'); ?>
    <!-- kopa-page-header -->
    <div class="bg-hb"></div>
    <div class="kopa-breadcrumb">
      <div class="wrapper clearfix">
        <div class="wrapper clearfix">
          <div class="pull-left"> <span>Register</span> </div>
          <div class="pull-right clearfix"> <span itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""> <a itemprop="url" href="Index.php"> <span itemprop="title">Home</span> </a> </span> &nbsp;/&nbsp; <span itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""> <a itemprop="url" class="current-page"> <span itemprop="title">Register</span> </a> </span> </div>
        </div>
      </div>
    </div>
    <!--/end .breadcrumb-->
    <div id="main-content">
        <section class="kopa-area kopa-area-1">
            <div class="wrapper">

                <div class="row">

                    <div class="kopa-main-col col-md-9 col-sm-9 col-xs-9">
                        <div class="kopa-contact-wrapper">
                            
                            <!-- row -->
                            <div class="row">
                            
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                </div>
                                <!-- col-md-12 -->
                            </div>
                            <!-- row -->
                        </div>
                        <!-- contact-wrapper -->
                        <div class="contact-box">
                            
                            <form name="form" class="contact-form clearfix" action="<?php echo $editFormAction; ?>" method="POST">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4 col-xs-4">
                                        <p class="input-block">
                                            <input type="text" name="name" class="valid" required>
                                        </p>
                                    </div>
                                    <!-- col-md-3 -->
                                    <div class="col-md-8 col-sm-8 col-xs-8">
                                        <div class="input-label">
                                            <p>UserName<span>*</span></p>
                                        
                                        </div>
                                    </div>
                                    <!-- col-md-9 -->
                                </div>
                                <!-- row --> 
                                <div class="row">
                                    <div class="col-md-4 col-sm-4 col-xs-4">
                                        <p class="input-block">
                                            <input type="email" name="email" class="valid" required>
                                        </p>
                                    </div>
                                    <!-- col-md-3 -->
                                    <div class="col-md-8 col-sm-8 col-xs-8">
                                        <div class="input-label">
                                            <p>Email Address <span>*</span></p>
                                         
                                        </div>
                                    </div>
                                    <!-- col-md-9 -->
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-sm-4 col-xs-4">
                                        <p class="input-block">
                                            <input type="password" name="password" class="valid" required>
                                        </p>
                                    </div>
                                    <!-- col-md-3 -->
                                    <div class="col-md-8 col-sm-8 col-xs-8">
                                        <div class="input-label">
                                            <p>Password <span>*</span></p>
                                         
                                        </div>
                                    </div>
                                    <!-- col-md-9 -->
                                </div>
                                <!-- row -->
                                
                                <!-- row -->
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <p class="contact-button clearfix">                    
                                            <span><input type="submit" name="submit" value="Register" id="submit-contact"></span>
                                        </p>
                                    </div>
                                    <!-- col-md-12 -->
                                </div>
                                <!-- row -->
                                <input type="hidden" name="MM_insert" value="form"> 
                            </form>
                            <div id="response"></div>
                        </div>
                        <!-- contact-box -->
                        <div class="col-md-6 col-xs-6 col-sm-6"  style="margin-left: 580px; margin-top: -250px;">
                            <div class="kopa-tab-widget clearfix">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="#e-tab1" data-toggle="tab">Tab 1</a></li>
                                    <li><a href="#e-tab2" data-toggle="tab">Tab 2</a></li>
                                    <li><a href="#e-tab3" data-toggle="tab">Tab 3</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="e-tab1">
                                       Get yourself registered here
                                    </div>
                                    <div class="tab-pane" id="e-tab2">
                                                               Get yourself registered here
                                    </div>
                                    <div class="tab-pane" id="e-tab3">
                                                               Get yourself registered here
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- col-md-9 -->
					
                    <!-- widget_archive -->

                </div>
                <!-- row -->

            </div>    
			<div class="mb-30"></div>
        </section>
        <!-- kopa-area kopa-area-1 -->   
		<section class="kopa-area-3">

            <div class="wrapper">

                <div class="left-area">
                    <div class="widget kopa-social-link-widget">
                        <span>Stay in touch</span>
                            <ul class="social-links pull-left clearfix">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-google-plus"></a></li>
                            
                        </ul>
                    </div>
                    <!-- kopa-social-link-widget --> 
                </div>
                <!-- left-area --> 

                <div class="right-area">
                    <div class="widget kopa-newsletter-widget">
                        <span class="news-icon fa fa-envelope"></span>
                        <div class="media-body">
                            <p>usama@designpalace.com</p> <br/>
                             <p>haseeb@designpalace.com</p>
                            
                            <div id="newsletter-response"></div>
                        </div>
                    </div>
                    <!-- kopa-newsletter-widget -->
                </div>
                <!-- right-area --> 

            </div>

        </section>
        <!-- end .kopa-area-3 -->
		
    </div>
    <!-- main-content -->

    
    <!-- bottom-sidebar -->

    <?php include('footer.php'); ?>
    <!-- kopa-page-footer -->

    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="js/custom.js" charset="utf-8"></script>
    
</body>


</html>
