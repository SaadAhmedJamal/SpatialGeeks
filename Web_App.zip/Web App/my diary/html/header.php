<?php require_once('Connections/dbconfig.php'); 

mysql_select_db("designpalace");

//session_start();

if ( !isset($_SESSION['SESS_NAME']) ) {
	//header('location: login.php');
} else {
	
	$l = "SELECT * FROM register WHERE email = '{$_SESSION['SESS_NAME']}'";
//	echo $l . "<br/>";
$result = mysql_query($l);
$user_arr = mysql_fetch_array($result);
}


?>
<header class="kopa-page-header">

        <div class="kopa-header-top">

            <div class="wrapper clearfix">

                <div class="hotline-box pull-left wow fadeIn" data-wow-duration="0.4s" data-wow-delay="0.4s">
                 <?php
				 if (isset($_SESSION['SESS_NAME']) ) {
					 
					 echo $user_arr['username'];
				 }
				 else
				 {
				  ?>   
                    <h6 class="wow fadeInLeft" data-wow-duration="0.6s" data-wow-delay="0.6s">
                     <a href="login.php">Login </a>|<a href="register.php">Register</a> </h6>
                  <?php } ?>   
                    <span class="triangle-wrapper"></span>
                    <span class="triangle"></span>

                    <div class="kopa-border-bottom"></div>
                </div>
                <!-- hotlinebox -->

                <div class="ss-box pull-right clearfix">

                    <ul class="social-links pull-left clearfix wow fadeInRight" data-wow-duration="0.6s" data-wow-delay="0.6s">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-google-plus"></a></li>
                        
                    </ul>
                    <!-- social-links -->

                    <div class="search-box pull-right clearfix wow fadeInRight" data-wow-duration="0.6s" data-wow-delay="0.6s">
                        <form action="#" class="search-form clearfix" method="get">
                            <input type="text" onBlur="if (this.value == '')
                                this.value = this.defaultValue;" onFocus="if (this.value == this.defaultValue)
                                this.value = '';" value="Search this site" name="s" class="search-text">
                            <button type="submit" class="search-submit"><span class="fa fa-search"></span>
                        </button>
                        </form>
                        <!-- search-form -->
                    </div>
                    <!--search-box-->

                </div>
                <!-- ss-box -->

                <div class="left-bg-color wow fadeIn" data-wow-duration="0.4s" data-wow-delay="0.4s">
                    <div class="kopa-border-bottom"></div>
                </div>

            </div>
            <!-- wrapper -->

        </div>
        <!-- kopa-header-top -->

        <div class="kopa-header-bottom ">

            <div class="wrapper clearfix">

                <div class="left-color-bg">
                    <div class="left-color-bg-outer"></div>
                    <div class="triangle"></div>
                </div>

                <div class="logo-box pull-left">
                    <a href="index.php"><img src="placeholders/logo.png" alt="" /></a>
                </div>
                <!-- logo-box -->

                <nav class="main-nav pull-right">

                    <ul class="main-menu clearfix">
                        <li class="current-menu-item">
                            <a href="index.php">Home</a>
                            
                        </li>
                        <li>
                            <a href="logo.php">Logos</a>
                           
                        </li>
                        <li>
                            <a href="businesscard.php">Business Cards</a>
                            
                        </li>
                        <li><a href="wedding_card.php">Wedding Cards</a></li>
                        
                         <li><a href="banners.php">Banners</a></li>
                        
                        <li><a href="contact.php">Contact Us</a></li>
                       
                    </ul>
                    <!-- main-menu -->

                </nav>
                <!-- main-nav -->

                <nav class="main-nav-mobile clearfix">
                    <a class="pull"><span class="fa fa-align-justify"></span></a>
                    <ul class="main-menu-mobile clearfix">
                        <li class="current-menu-item">
                          <a href="index.php">Home</a>
                            
                        </li>
                        <li>
                           <a href="#">Logo Design</a>
                            
                        </li>
                         <li>
                            <a href="#">Business Card Design</a>
                            
                        </li>
                        <li><a href="#">Wedding Card Design</a></li>
                        
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </nav>
            <!--/main-menu-mobile-->

            </div>
            <!-- wrapper -->

        </div>
        <!-- kopa-header-bottom -->

        <div class="kopa-header-top-2">

            <div class="wrapper clearfix">

            
                <ul class="social-links pull-left clearfix wow fadeInRight" data-wow-duration="0.6s" data-wow-delay="0.6s">
                    <li><a href="#" class="fa fa-facebook"></a></li>
                    <li><a href="#" class="fa fa-twitter"></a></li>
                   
                    <li><a href="#" class="fa fa-google-plus"></a></li>
                    
                </ul>
                <!-- social-links -->

                <div class="search-box pull-right clearfix wow fadeInRight" data-wow-duration="0.6s" data-wow-delay="0.6s">
                    <form action="#" class="search-form clearfix" method="get">
                        <input type="text" onBlur="if (this.value == '')
                            this.value = this.defaultValue;" onFocus="if (this.value == this.defaultValue)
                            this.value = '';" value="Search this site" name="s" class="search-text">
                        <button type="submit" class="search-submit"><span class="fa fa-search"></span>
                    </button>
                    </form>
                    <!-- search-form -->
                </div>
                <!--search-box-->

    
            </div>
            <!-- wrapper -->

        </div>
        <!-- kopa-header-top-2 -->

    </header>