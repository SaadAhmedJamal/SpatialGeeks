
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>My Diary</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>


<body>
<param value="False" name="autoStart" />
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main">
    <div class="leftmenu">
      <div class="nav">
        <ul>
         <li><a href="upload_video.php">upload video</a></li>
         
          <li><a href="homepage.php">home</a></li>
           
           
          
        </ul>
      </div>
    </div>
    <div id="main" style="width: 500px;
margin-left: 220px;">
    <?php
$con = mysql_connect("127.0.0.1", "root", "");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("abc", $con);

$result = mysql_query("SELECT * FROM video" );


while($row = mysql_fetch_array($result))
  {

  //echo "<img width=100 height=100 alt='Unable to View' src='" . $row["location"] . "'>";

// echo '<a href="photocomment.php?id=' . $row["photo_id"] . '>' . "<img width=100 height=100 alt='Unable to View' src='". $row["location"] . "'>" . '</a>';
 
 echo '<video style="width:150px; height:150px"  controls  > 
<source src="'. $row["location"] . '"/> 
</video>';

  echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	
  }

mysql_close($con);
?>
    
    
   
    </div>
    
    <param value="True" name="Showcontrols" />
    
  </div>
  
  
  <div id="prefooter">
    
  </div>
  
  <div id="footer">
    <div class="padding"> Copyright &copy; 2006 Your Site Name | Design: <a href="http://www.free-css-templates.com">David Herreman </a> | <a href="http://www.free-css.com/">Contact</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> and <a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://www.solucija.com">Solucija.com</a> | <a href="http://www.free-css.com/">Login</a> </div>
  </div>
</div>

</body>
</html>