<?php require_once('Connections/dbconfig.php'); ?>

<?php session_start();
if (!isset($_SESSION['MM_Username'])){
	
	header('login.php');
	} else {
		
		$l= "SELECT * FROM signup ";
		$result= mysql_query($l);
		$user_ar= mysql_fetch_array($result);
		}
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>View</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      <h2><?php echo $user_ar['firstname']; ?>'s diary</h2>
      
    </div>
    
  </div>
  <div id="main1">
    
    
      <div class="nav">
        <ul>
         <li><a href="viewdiary.php">View Previous Diaries</a></li>
          <li><a href="diary.php">New Diary</a></li>
          
          
          
        </ul>
      </div>
    
    

  </div>
  <div id="prefooter"></div>
</div>
</body>
</html>

