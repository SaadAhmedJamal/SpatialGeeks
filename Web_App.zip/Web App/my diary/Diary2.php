<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>My Diary</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>


<body>
<param value="False" name="autoStart" />
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
      
    </div>
  </div>
  <div id="main1">
    <param value="True" name="Showcontrols" />
     <form name="form" action="<?php echo $editFormAction; ?>" method="POST">
  <textarea name="diary" cols="50" rows="25" style="size:landscape; background-color:transparent; alignment-adjust:central;/* margin-right: 100px; */margin-left: -100px;"></textarea>
 <input name="Save" type="submit" value="Save" style="margin-left:450px; size:500px;height: 30px;width: inherit;width: 60px;">
  <input type="hidden" name="MM_insert" value="form" />
       <a href="homepage.php"><input name="Home" type="button" value="Home" style="margin-left:200px; size:500px;height: 30px;width: inherit;width: 60px; " /> </a>
          
  </form>
   <div>
   <div id="main" style="width: 500px;
margin-left: 250px;" ></div>
    </div>
    
  </div>
  
  
  
  <div id="prefooter">
    
  </div>
  
  <div id="footer">
    <div class="padding"> Copyright &copy; 2006 Your Site Name | Design: <a href="http://www.free-css-templates.com">David Herreman </a> | <a href="http://www.free-css.com/">Contact</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> and <a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://www.solucija.com">Solucija.com</a> | <a href="http://www.free-css.com/">Login</a> </div>
  </div>
</div>

</body>
</html>