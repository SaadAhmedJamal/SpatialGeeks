<?php require_once('Connections/dbconfig.php'); ?>
<?php
session_start();
if (!isset($_SESSION['MM_Username'])){
	
	header('login.php');
	} else {
		
		$l= "SELECT * FROM signup WHERE email = '{$_SESSION['MM_Username']}' ";
		$result= mysql_query($l);
		$user_ar= mysql_fetch_array($result);
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<style type="text/css" media="all">
@import "images/style.css";
</style>
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>MY DIARY</h1>
        <h2><?php echo $user_ar['firstname']; ?>'s diary</h2>
 <form name="video" enctype="multipart/form-data" method="post" action="saveupload2.php">
<input name="MAX_FILE_SIZE" value="100000000000000"  type="hidden"/><br />
<input type="file" name="uploadvideo" style="margin-top:300px; margin-left:150px;" /><br />
<input type="submit" name="upload" value="SUBMIT" style="margin-left:200px;" />
</form>

    </div>
  </div>
  <div id="main1"></div>
  <div id="prefooter"></div>
  <div id="footer"></div>
</div>
</body>
</html>
